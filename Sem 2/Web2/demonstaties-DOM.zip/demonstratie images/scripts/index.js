const setup = () => {
  let btnVoegToe = document.getElementById("btnVoegToe"); //button opvragen via DOM
  btnVoegToe.addEventListener("click", voegToe); //functie voegToe uitvoegen als click-event getriggerd wordt.
  document.getElementById("btnDelete").addEventListener("click", verwijder);
};

const voegToe = () => {
  let txtInput = document.getElementById("txtInput"); //input veld opvragen via dom
  let url = txtInput.value; //tekst dat in het invoer veld staat opslaan (! =/= textContent of innerHTML)
  let divImages = document.getElementById("divImages"); //div opvragen via DOM die klaar staat om een foto aan toe te voegen
  divImages.innerHTML += "<img src='" + url + "'>"; // image tag toevoegen via innerhtml met de url die we eerder hadden opgevraagd (test ook eens met textConent methode ipv innerHTML). Let op de += die de html uitbreid ipv vervangt.
  txtInput.value = ""; //het input veld leeg maken
};

const verwijder = () => {
  let fotos = document.querySelectorAll("#divImages img");
  for (let foto of fotos) {
    //door de NodeList gaan
    foto.remove(); //werkt niet in IE
  }
  //of
  //document.getElementById("divImages").innerHTML = "";
};

window.addEventListener("load", setup);
