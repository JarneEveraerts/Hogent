﻿// 3 manieren:
// 1. @
// 2. \\ -> \
// 3. Linux-way: /
var fp = new FileProcessor("C:/Users/u2389/source/repos/Straatnamen/Straatnamen", "extract", "straatnamen");
//fp.Unzip("straatnamenInfo.zip");
fp.ReadFiles(new List<string> { 
    "straatnamen.csv",
    "Gemeentenaam.csv",
    "StraatnaamID_gemeenteID.csv",
    "ProvincieInfo.csv",
    "ProvincieIDsVlaanderen.csv"
});