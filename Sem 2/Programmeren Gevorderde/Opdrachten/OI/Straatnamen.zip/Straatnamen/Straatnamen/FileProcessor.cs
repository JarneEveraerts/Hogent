﻿using System.IO.Compression;

public class FileProcessor
{
    #region Properties
    private string _path;
    private string _extractPath;
    private string _resultPath;
    #endregion

    private class ProvincieGemeente
    {
        public string Gemeente { get; set; }
        public string Provincie { get; set; }

        public ProvincieGemeente(string provincie)
        {
            this.Provincie = provincie;
        }
    }

    public FileProcessor(string path, string extractPath, string resultPath)
    {
        this._path = path;
        this._extractPath = extractPath;
        this._resultPath = resultPath; 
    }

    public void ReadFiles(List<string> fileNames)
    {
        var provincieIds = new HashSet<int>();
        using (var p = new StreamReader(Path.Combine(_path, _extractPath, fileNames[4])))
        {
            /*
            if (p != null)
            {
                var l = p.ReadLine();
                if (l != null)
                {
                    var ids = l.Trim().Split(";");
                }
            }
            */
            var ids = p?.ReadLine()?.Trim()?.Split(",");
            if (ids != null)
            {
                foreach (var id in ids)
                {
                    provincieIds.Add(Int32.Parse(id));
                }
            }
            // G1: lees provincienamen + provincieid + gemeenteid
            Dictionary<int /* gemeenteId */, ProvincieGemeente> gemeenteProvincieLinks = new();
            // G2: gemeentenamen + gemeenteid: gebruik ook de gemeenteProvincieLinks structuur
            // G3: lees straatnaamid + gemeenteid
            Dictionary<int /* straatnaamid */, int /* gemeenteid */> straatnaamGemeenteLinks = new();
            // G4: lees straatnamen - vul _data op           
        }       
    }

    public void Unzip(string fileName)
    {
        // c:tmp
        // demo.txt
        var fileRef = Path.Combine(_path, fileName);
        if (File.Exists(fileRef))
            ZipFile.ExtractToDirectory(fileRef, Path.Combine(_path, _extractPath));
        else
            throw new Exception("File not found: \"" + fileRef + "\"");
    }
}