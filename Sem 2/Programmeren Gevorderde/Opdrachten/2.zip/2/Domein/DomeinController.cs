﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Domein
{

	public class DomeinController
	{
		private Garage _garage;
		public DomeinController(IAutoRepository autoRepo, IOnderhoudRepository onderhoudRepo)
		{
			_garage = new Garage(autoRepo, onderhoudRepo);
		}

		public List<string> GeefAutos()
		{
			return _garage.GeefAutos()
				.Select(Auto => Auto.ToString())
				.ToList();
		}

        public void RegistreerAuto(string v1, string v2, string v3)
        {
            throw new NotImplementedException();
        }

        public string GeefAuto(string v)
        {
            throw new NotImplementedException();
        }

        public void WijzigAuto(string v1, string v2, string v3)
        {
            throw new NotImplementedException();
        }

        public void VerwijderAuto(string v1, string v2, string v3)
        {
            throw new NotImplementedException();
        }
    }
}