﻿namespace Main
{
    public interface IConfigurator
    {
        public string DbConnection { get; set; }
    }
}