﻿namespace Main
{
    public static class Services
    {
        public static IConfigurator Configurator { get; set; }
    }
}