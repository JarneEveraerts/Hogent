﻿using Domein;
using System.Collections.Generic;

namespace Main
{
    public class AutoRepository : IAutoRepository
    {
        public List<Auto> GeefAutos()
        {
            //throw new System.NotImplementedException();
            return new List<Auto>();
        }
    }
}